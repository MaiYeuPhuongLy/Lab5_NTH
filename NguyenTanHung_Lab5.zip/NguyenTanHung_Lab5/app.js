const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const bodyParser = require('body-parser');
const productRoutes = require('./routes/productRoutes'); // Đảm bảo file routes này tồn tại và đúng đường dẫn

const app = express();

// Chuỗi kết nối MongoDB Atlas (thay thế bằng thông tin thực tế của bạn)
const dbURI = 'mongodb+srv://clyde:123@lab5.y3ymq.mongodb.net/express';

// Kết nối tới MongoDB Atlas
mongoose.connect(dbURI)
  .then(() => {
    console.log('Connected to MongoDB Atlas');
  })
  .catch((err) => {
    console.error('Database connection error:', err);
  });

// Cấu hình view engine
app.set('view engine', 'ejs');

// Cấu hình middleware
app.use(express.static('public')); // Thư mục chứa file tĩnh (CSS, hình ảnh, v.v.)
app.use(bodyParser.urlencoded({ extended: true })); // Middleware để xử lý dữ liệu form
app.use(bodyParser.json()); // Middleware để xử lý dữ liệu JSON

// Cấu hình session
app.use(session({ 
  secret: 'secret-key', // Bạn có thể thay thế bằng một khóa bí mật bảo mật hơn
  resave: false, // Không lưu session nếu không có thay đổi
  saveUninitialized: true // Lưu session ngay cả khi nó không có nội dung
}));

// Sử dụng các routes
app.use('/', productRoutes); // Các routes của sản phẩm

// Khởi động server
const port = process.env.PORT || 3000; // Sử dụng cổng từ biến môi trường hoặc cổng mặc định là 3000
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
